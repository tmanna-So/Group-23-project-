# Log File Analyzer and Pattern Detector

## 📋 Overview

A **production-ready Python CLI application** for analyzing server log files and application event logs. This tool provides comprehensive log analysis capabilities including pattern detection, performance monitoring, and anomaly identification.

### 🎯 Key Features
- **Log Parsing**: Read and process Apache, Nginx, and custom log formats
- **Pattern Detection**: Use regex to identify errors, anomalies, and user behavior patterns
- **Performance Analysis**: Track response times and system performance metrics
- **Anomaly Detection**: Identify unusual activity and peak usage periods
- **Alert System**: Generate alerts for critical events (e.g., repeated 500 errors)
- **Report Generation**: Create detailed analysis reports in multiple formats
- **Filtering**: Filter logs by date, type, severity, and other criteria

## 🚀 Quick Start

### Command-Line Analysis
```bash
python log_analyzer.py analyze sample_logs/real_apache.log
```

### Interactive Menu Interface
```bash
python log_analyzer.py menu
```

### Detailed Analysis with JSON Output
```bash
python log_analyzer.py analyze sample_logs/real_apache.log --detailed --output json
```

### Filtered Analysis
```bash
python log_analyzer.py analyze sample_logs/real_apache.log --level ERROR --start-date 2024-01-15
```

### Export to CSV
```bash
python log_analyzer.py analyze sample_logs/real_apache.log --output csv --output-file report.csv
```

## 📁 Project Structure

```
log_analyzer/
├── log_analyzer.py          # Main CLI application
├── log_parser.py            # Core parsing logic
├── pattern_detector.py      # Pattern detection and analysis
├── report_generator.py      # Report generation utilities
├── utils.py                 # Utility functions
├── tests/                   # Unit tests
│   ├── test_parser.py       # Parser tests
│   └── test_detector.py     # Detector tests
├── sample_logs/             # Sample log files for testing
│   └── real_apache.log      # Real-world Apache log sample
└── README.md               # This file
```

## 🛠️ Technical Requirements

### Core Requirements
- **Python 3.8+** with standard library only
- **Object-Oriented Programming** with inheritance and polymorphism
- **Modular and readable code** structure
- **Robust file handling** for reading/writing data
- **Input validation and error handling**
- **Clear documentation and comments**

### Standard Library Modules Used
1. **`re`** - Regular expressions for pattern matching
2. **`os`** - File system operations
3. **`datetime`** - Date and time handling
4. **`json`** - JSON data handling
5. **`argparse`** - Command-line argument parsing
6. **`collections`** - Data structures (defaultdict, Counter)
7. **`statistics`** - Statistical calculations
8. **`csv`** - CSV file handling
9. **`abc`** - Abstract base classes
10. **`dataclasses`** - Data structure classes
11. **`typing`** - Type hints
12. **`io`** - Input/output utilities

## 🏗️ Architecture

### Object-Oriented Design
- **`BaseLogParser`** - Abstract base class for log parsers
- **`ApacheLogParser`** - Concrete implementation for Apache logs
- **`NginxLogParser`** - Concrete implementation for Nginx logs
- **`GenericLogParser`** - Generic parser for custom formats
- **`LogParserFactory`** - Factory pattern for parser creation
- **`PatternDetector`** - Analysis and pattern detection
- **`ReportGenerator`** - Polymorphic report generation

### Design Patterns
- **Factory Pattern**: `LogParserFactory` for parser creation
- **Strategy Pattern**: Different report generators
- **Template Method Pattern**: Base parser with specific implementations
- **Observer Pattern**: Alert generation system

## 📊 Analysis Capabilities

### Error Detection
- **4xx/5xx Status Codes**: Client and server errors
- **Repeated Errors**: Pattern identification
- **Error Rate Calculation**: Percentage analysis
- **Critical Issue Alerts**: High error rate detection

### Performance Analysis
- **Response Time Statistics**: Mean, median, min, max
- **Slow Request Identification**: Performance bottlenecks
- **Throughput Analysis**: Requests per time period
- **Peak Usage Detection**: High traffic periods

### Security Analysis
- **Suspicious IP Detection**: High error rate IPs
- **Failed Login Attempts**: Authentication failures
- **Anomaly Detection**: Statistical outlier identification
- **Threat Pattern Recognition**: Security incident detection

### Traffic Analysis
- **Hourly/Daily Patterns**: Usage trends
- **Top Endpoints**: Most accessed resources
- **User Agent Analysis**: Client type distribution
- **Geographic Patterns**: IP-based analysis

## 📈 Output Formats

### Text Reports (Default)
- Human-readable formatted output
- Summary statistics and critical issues
- Traffic analysis and recommendations
- Detailed sections for comprehensive analysis

### JSON Reports
- Machine-readable structured data
- Complete analysis results
- Metadata and timestamps
- API-friendly format

### CSV Reports
- Spreadsheet-compatible format
- Tabular data representation
- Easy data import/export
- Statistical analysis ready

## 🔧 Command Line Interface

The application supports two interfaces: command-line arguments and interactive menu.

### Command-Line Interface

#### Main Command
```bash
python log_analyzer.py analyze <log_file> [options]
```

#### Options
- `--start-date YYYY-MM-DD` - Filter logs from start date
- `--end-date YYYY-MM-DD` - Filter logs until end date
- `--level LEVEL` - Filter by log level (ERROR, WARN, INFO, DEBUG)
- `--threshold N` - Set alert threshold (default: 10)
- `--detailed` - Generate detailed report
- `--output FORMAT` - Output format (txt, json, csv)
- `--output-file FILE` - Save report to file

#### Examples
```bash
# Basic analysis
python log_analyzer.py analyze logs/server.log

# Filter by date range
python log_analyzer.py analyze logs/server.log --start-date 2024-01-01 --end-date 2024-01-31

# Error-only analysis with JSON output
python log_analyzer.py analyze logs/server.log --level ERROR --output json --detailed

# Export to CSV file
python log_analyzer.py analyze logs/server.log --output csv --output-file analysis_report.csv
```

### Interactive Menu Interface

#### Start Menu Interface
```bash
python log_analyzer.py menu
```

#### Menu Features
- **📁 Load a log file** - Interactive file selection with validation
- **🔍 Analyze error patterns** - Step-by-step error analysis with customizable thresholds
- **📊 Track user/system behavior** - Real-time traffic and behavior analysis
- **⚡ Calculate performance metrics** - Response time and performance statistics
- **🚨 Generate alert report** - Critical issue alerts and recommendations
- **📄 Export full analysis summary** - Multiple output formats with file saving
- **🚪 Exit** - Clean application exit

#### Menu Benefits
- ✅ **Beginner-friendly** - Step-by-step guidance
- ✅ **Interactive validation** - Real-time input checking
- ✅ **Visual feedback** - Emojis and clear status messages
- ✅ **Multiple formats** - TXT, JSON, CSV output options
- ✅ **File management** - Save reports to files
- ✅ **Error handling** - User-friendly error messages

## 🧪 Testing

### Run All Tests
```bash
python -m unittest tests.test_parser -v
python -m unittest tests.test_detector -v
```

### Test Coverage
- **Parser Tests**: 22 test cases covering all parser functionality
- **Detector Tests**: 12 test cases covering analysis logic
- **Edge Cases**: Invalid input, error conditions, boundary cases
- **Integration Tests**: End-to-end functionality testing

## 📝 Log Format Support

### Apache Log Format
```
192.168.1.100 - - [15/Jan/2024:08:30:15 +0000] "GET /api/users HTTP/1.1" 200 1234 "https://example.com" "Mozilla/5.0"
```

### Nginx Log Format
```
192.168.1.200 - user1 [15/Jan/2024:11:00:00 +0000] "GET /api/v1/users HTTP/1.1" 200 1234 "https://example.com" "Mozilla/5.0" "-"
```

### Generic Log Format
- Automatic format detection
- Heuristic parsing for custom formats
- Extensible for specific requirements

## 🎓 Academic Requirements Met

### ✅ Core Requirements
- **Python 3.8+ Standard Library**: No external dependencies
- **Object-Oriented Programming**: Inheritance and polymorphism
- **Modular Design**: Clear separation of concerns
- **File Handling**: Robust I/O operations
- **Input Validation**: Comprehensive validation
- **Error Handling**: Graceful error management
- **Documentation**: Clear and concise
- **Testing**: Comprehensive unit tests

### ✅ Advanced Features
- **Pattern Detection**: Regex-based analysis
- **Performance Metrics**: Statistical calculations
- **Multiple Output Formats**: TXT, JSON, CSV
- **Real-World Applicability**: Production-ready code
- **Scalable Design**: Handles large log files

## 🚀 Production Features

### Real-World Data Support
- **Realistic Log Formats**: Apache Combined Log Format
- **Diverse HTTP Scenarios**: All common status codes
- **Multiple HTTP Methods**: GET, POST, PUT, DELETE
- **Real User Agents**: Browser and service user agents
- **Time-based Analysis**: Hourly and daily patterns

### Quality Assurance
- **34 Unit Tests**: Comprehensive test coverage
- **Error Handling**: Robust exception management
- **Input Validation**: Comprehensive validation
- **Memory Efficient**: Line-by-line processing
- **Cross-platform**: Windows, macOS, Linux compatible

## 📞 Support

This project demonstrates advanced Python programming concepts while remaining accessible to students. The codebase is production-ready and can be used for real log analysis tasks.

### Key Learning Outcomes
- Object-Oriented Programming with inheritance and polymorphism
- Design patterns (Factory, Strategy, Template Method)
- File I/O and data processing
- Regular expressions and pattern matching
- Statistical analysis and anomaly detection
- Command-line interface development
- Unit testing and quality assurance

---

**Ready for production use with real log data!** 🚀✨ 