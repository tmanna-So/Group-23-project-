"""
Report Generator Module - Report generation utilities

This module provides comprehensive report generation capabilities for log analysis results.
It supports multiple output formats (TXT, JSON, CSV) and uses polymorphism to handle
different report types and formats.

The module includes:
- Text report generator for human-readable output
- JSON report generator for structured data
- CSV report generator for spreadsheet compatibility
- Polymorphic design for easy format extension
- Detailed and summary report options
"""

import json
import csv
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Dict, Any, Optional
from io import StringIO

from log_parser import LogEntry
from pattern_detector import AnalysisResult


class BaseReportGenerator(ABC):
    """
    Abstract base class for report generators.
    
    This class defines the interface that all report generators must implement.
    It enforces consistency across different output formats while allowing
    for format-specific generation logic.
    """
    
    @abstractmethod
    def generate(self, log_entries: List[LogEntry], 
                analysis_results: AnalysisResult,
                detailed: bool = False,
                source_file: str = "") -> str:
        """
        Generate a report in the specific format.
        
        Args:
            log_entries: List of parsed log entries
            analysis_results: Results from pattern analysis
            detailed: Whether to generate detailed report
            source_file: Source log file path
            
        Returns:
            String representation of the report
        """
        pass
    
    @abstractmethod
    def get_format_name(self) -> str:
        """
        Return the name of the report format.
        
        Returns:
            String identifier for the report format
        """
        pass


class TextReportGenerator(BaseReportGenerator):
    """
    Text report generator for human-readable output.
    
    This generator creates formatted text reports that are easy to read
    and understand. It includes sections for summary, details, alerts,
    and recommendations.
    """
    
    def generate(self, log_entries: List[LogEntry], 
                analysis_results: AnalysisResult,
                detailed: bool = False,
                source_file: str = "") -> str:
        """
        Generate a human-readable text report.
        
        Args:
            log_entries: List of parsed log entries
            analysis_results: Results from pattern analysis
            detailed: Whether to generate detailed report
            source_file: Source log file path
            
        Returns:
            Formatted text report
        """
        report_lines = []
        
        # Header
        report_lines.append("=" * 60)
        report_lines.append("LOG ANALYSIS REPORT")
        report_lines.append("=" * 60)
        report_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        if source_file:
            report_lines.append(f"Source File: {source_file}")
        report_lines.append("")
        
        # Summary section
        report_lines.extend(self._generate_summary_section(analysis_results))
        
        # Critical issues section
        if analysis_results.alerts:
            report_lines.extend(self._generate_alerts_section(analysis_results))
        
        # Performance section
        if analysis_results.response_time_stats:
            report_lines.extend(self._generate_performance_section(analysis_results))
        
        # Traffic analysis section
        if analysis_results.hourly_traffic:
            report_lines.extend(self._generate_traffic_section(analysis_results))
        
        # Detailed sections (if requested)
        if detailed:
            report_lines.extend(self._generate_detailed_sections(analysis_results))
        
        # Recommendations section
        report_lines.extend(self._generate_recommendations_section(analysis_results))
        
        # Footer
        report_lines.append("")
        report_lines.append("=" * 60)
        report_lines.append("End of Report")
        report_lines.append("=" * 60)
        
        return "\n".join(report_lines)
    
    def _generate_summary_section(self, results: AnalysisResult) -> List[str]:
        """Generate the summary section of the report."""
        lines = []
        lines.append("SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Total Log Entries: {results.total_entries:,}")
        lines.append(f"Total Requests: {results.total_requests:,}")
        
        if results.average_response_time:
            lines.append(f"Average Response Time: {results.average_response_time:.2f}ms")
        
        lines.append(f"Error Rate: {results.error_rate:.2%} ({results.error_count} errors)")
        
        # Peak usage
        if results.peak_usage_periods:
            peak = results.peak_usage_periods[0]
            lines.append(f"Peak Usage: {peak['hour'].strftime('%Y-%m-%d %H:00')} "
                        f"({peak['request_count']} requests)")
        
        lines.append("")
        return lines
    
    def _generate_alerts_section(self, results: AnalysisResult) -> List[str]:
        """Generate the alerts section of the report."""
        lines = []
        lines.append("CRITICAL ISSUES")
        lines.append("-" * 40)
        
        for alert in results.alerts:
            severity_icon = "🔴" if alert['severity'] == 'high' else "🟡"
            lines.append(f"{severity_icon} {alert['message']}")
        
        lines.append("")
        return lines
    
    def _generate_performance_section(self, results: AnalysisResult) -> List[str]:
        """Generate the performance section of the report."""
        lines = []
        lines.append("PERFORMANCE METRICS")
        lines.append("-" * 40)
        
        stats = results.response_time_stats
        if stats:
            lines.append(f"Response Time Statistics:")
            lines.append(f"  Minimum: {stats['min']:.2f}ms")
            lines.append(f"  Maximum: {stats['max']:.2f}ms")
            lines.append(f"  Average: {stats['mean']:.2f}ms")
            lines.append(f"  Median: {stats['median']:.2f}ms")
            lines.append(f"  Standard Deviation: {stats['std_dev']:.2f}ms")
        
        if results.slow_requests:
            lines.append(f"\nSlow Requests (>1000ms): {len(results.slow_requests)}")
            for i, request in enumerate(results.slow_requests[:5]):  # Show top 5
                lines.append(f"  {i+1}. {request['endpoint']} - {request['response_time']:.0f}ms "
                           f"({request['timestamp'].strftime('%H:%M:%S')})")
        
        lines.append("")
        return lines
    
    def _generate_traffic_section(self, results: AnalysisResult) -> List[str]:
        """Generate the traffic analysis section of the report."""
        lines = []
        lines.append("TRAFFIC ANALYSIS")
        lines.append("-" * 40)
        
        # Top endpoints
        if results.top_endpoints:
            lines.append("Top Endpoints:")
            for endpoint, count in results.top_endpoints[:5]:
                lines.append(f"  {endpoint}: {count:,} requests")
        
        # Top user agents
        if results.top_user_agents:
            lines.append("\nTop User Agents:")
            for agent, count in results.top_user_agents[:3]:
                # Truncate long user agent strings
                short_agent = agent[:60] + "..." if len(agent) > 60 else agent
                lines.append(f"  {short_agent}: {count:,} requests")
        
        # Peak usage periods
        if results.peak_usage_periods:
            lines.append("\nPeak Usage Periods:")
            for i, peak in enumerate(results.peak_usage_periods[:3]):
                lines.append(f"  {i+1}. {peak['hour'].strftime('%Y-%m-%d %H:00')}: "
                           f"{peak['request_count']} requests "
                           f"({peak['peak_factor']:.1f}x average)")
        
        lines.append("")
        return lines
    
    def _generate_detailed_sections(self, results: AnalysisResult) -> List[str]:
        """Generate detailed sections of the report."""
        lines = []
        
        # Status code distribution
        if results.status_code_distribution:
            lines.append("STATUS CODE DISTRIBUTION")
            lines.append("-" * 40)
            for status_code, count in sorted(results.status_code_distribution.items()):
                percentage = (count / results.total_entries) * 100
                lines.append(f"  {status_code}: {count:,} ({percentage:.1f}%)")
            lines.append("")
        
        # Repeated errors
        if results.repeated_errors:
            lines.append("REPEATED ERRORS")
            lines.append("-" * 40)
            for error in results.repeated_errors[:5]:
                lines.append(f"  {error['status_code']} on {error['endpoint']}: "
                           f"{error['count']} occurrences")
            lines.append("")
        
        return lines
    
    def _generate_recommendations_section(self, results: AnalysisResult) -> List[str]:
        """Generate the recommendations section of the report."""
        lines = []
        lines.append("RECOMMENDATIONS")
        lines.append("-" * 40)
        
        for i, recommendation in enumerate(results.recommendations, 1):
            lines.append(f"{i}. {recommendation}")
        
        lines.append("")
        return lines
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "Text"


class JSONReportGenerator(BaseReportGenerator):
    """
    JSON report generator for structured data output.
    
    This generator creates JSON reports that are suitable for programmatic
    processing and integration with other tools. The output is structured
    and includes all analysis data in a machine-readable format.
    """
    
    def generate(self, log_entries: List[LogEntry], 
                analysis_results: AnalysisResult,
                detailed: bool = False,
                source_file: str = "") -> str:
        """
        Generate a JSON report.
        
        Args:
            log_entries: List of parsed log entries
            analysis_results: Results from pattern analysis
            detailed: Whether to generate detailed report
            source_file: Source log file path
            
        Returns:
            JSON string representation of the report
        """
        report_data = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "source_file": source_file,
                "format": "json",
                "detailed": detailed
            },
            "summary": {
                "total_entries": analysis_results.total_entries,
                "total_requests": analysis_results.total_requests,
                "average_response_time": analysis_results.average_response_time,
                "error_count": analysis_results.error_count,
                "error_rate": analysis_results.error_rate
            },
            "alerts": analysis_results.alerts,
            "recommendations": analysis_results.recommendations,
            "performance": {
                "response_time_stats": analysis_results.response_time_stats,
                "slow_requests": analysis_results.slow_requests
            },
            "traffic": {
                "hourly_traffic": analysis_results.hourly_traffic,
                "daily_traffic": analysis_results.daily_traffic,
                "top_endpoints": [{"endpoint": ep, "count": count} 
                                 for ep, count in analysis_results.top_endpoints],
                "top_user_agents": [{"user_agent": ua, "count": count} 
                                   for ua, count in analysis_results.top_user_agents],
                "peak_usage_periods": [
                    {
                        "hour": peak["hour"].isoformat(),
                        "request_count": peak["request_count"],
                        "peak_factor": peak["peak_factor"]
                    }
                    for peak in analysis_results.peak_usage_periods
                ]
            },
            "security": {
                "suspicious_ips": analysis_results.suspicious_ips,
                "failed_logins": [
                    {
                        "timestamp": login["timestamp"].isoformat(),
                        "ip_address": login["ip_address"],
                        "message": login["message"],
                        "endpoint": login["endpoint"]
                    }
                    for login in analysis_results.failed_logins
                ]
            },
            "anomalies": analysis_results.anomalies
        }
        
        # Add detailed sections if requested
        if detailed:
            report_data["details"] = {
                "status_code_distribution": analysis_results.status_code_distribution,
                "repeated_errors": [
                    {
                        "status_code": error["status_code"],
                        "endpoint": error["endpoint"],
                        "count": error["count"],
                        "first_occurrence": error["first_occurrence"].isoformat(),
                        "last_occurrence": error["last_occurrence"].isoformat(),
                        "time_span": str(error["time_span"])
                    }
                    for error in analysis_results.repeated_errors
                ]
            }
        
        return json.dumps(report_data, indent=2, default=str)
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "JSON"


class CSVReportGenerator(BaseReportGenerator):
    """
    CSV report generator for spreadsheet compatibility.
    
    This generator creates CSV reports that can be easily imported into
    spreadsheet applications like Excel or Google Sheets. It provides
    multiple CSV files for different aspects of the analysis.
    """
    
    def generate(self, log_entries: List[LogEntry], 
                analysis_results: AnalysisResult,
                detailed: bool = False,
                source_file: str = "") -> str:
        """
        Generate CSV reports.
        
        Args:
            log_entries: List of parsed log entries
            analysis_results: Results from pattern analysis
            detailed: Whether to generate detailed report
            source_file: Source log file path
            
        Returns:
            Multi-section CSV report
        """
        output = StringIO()
        
        # Summary section
        output.write("SUMMARY\n")
        output.write("Metric,Value\n")
        output.write(f"Total Entries,{analysis_results.total_entries}\n")
        output.write(f"Total Requests,{analysis_results.total_requests}\n")
        if analysis_results.average_response_time:
            output.write(f"Average Response Time (ms),{analysis_results.average_response_time:.2f}\n")
        output.write(f"Error Count,{analysis_results.error_count}\n")
        output.write(f"Error Rate,{analysis_results.error_rate:.4f}\n")
        output.write("\n")
        
        # Alerts section
        if analysis_results.alerts:
            output.write("ALERTS\n")
            output.write("Type,Message,Severity\n")
            for alert in analysis_results.alerts:
                output.write(f"{alert['type']},{alert['message']},{alert['severity']}\n")
            output.write("\n")
        
        # Top endpoints
        if analysis_results.top_endpoints:
            output.write("TOP ENDPOINTS\n")
            output.write("Endpoint,Request Count\n")
            for endpoint, count in analysis_results.top_endpoints:
                output.write(f"{endpoint},{count}\n")
            output.write("\n")
        
        # Status code distribution
        if analysis_results.status_code_distribution:
            output.write("STATUS CODE DISTRIBUTION\n")
            output.write("Status Code,Count,Percentage\n")
            for status_code, count in sorted(results.status_code_distribution.items()):
                percentage = (count / analysis_results.total_entries) * 100
                output.write(f"{status_code},{count},{percentage:.2f}\n")
            output.write("\n")
        
        # Hourly traffic
        if analysis_results.hourly_traffic:
            output.write("HOURLY TRAFFIC\n")
            output.write("Hour,Request Count\n")
            for hour in range(24):
                count = analysis_results.hourly_traffic.get(hour, 0)
                output.write(f"{hour:02d}:00,{count}\n")
            output.write("\n")
        
        # Recommendations
        if analysis_results.recommendations:
            output.write("RECOMMENDATIONS\n")
            output.write("Number,Recommendation\n")
            for i, recommendation in enumerate(analysis_results.recommendations, 1):
                output.write(f"{i},{recommendation}\n")
        
        return output.getvalue()
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "CSV"


class ReportGenerator:
    """
    Main report generator class that orchestrates report creation.
    
    This class uses the Factory pattern to create appropriate report generators
    based on the requested output format. It provides a unified interface for
    generating reports in different formats.
    """
    
    def __init__(self):
        """Initialize the report generator with available formats."""
        self.generators = {
            'txt': TextReportGenerator(),
            'json': JSONReportGenerator(),
            'csv': CSVReportGenerator()
        }
    
    def generate_report(self, log_entries: List[LogEntry],
                       analysis_results: AnalysisResult,
                       output_format: str = 'txt',
                       detailed: bool = False,
                       source_file: str = "") -> str:
        """
        Generate a report in the specified format.
        
        Args:
            log_entries: List of parsed log entries
            analysis_results: Results from pattern analysis
            output_format: Desired output format ('txt', 'json', 'csv')
            detailed: Whether to generate detailed report
            source_file: Source log file path
            
        Returns:
            String representation of the report in the specified format
            
        Raises:
            ValueError: If the output format is not supported
        """
        if output_format not in self.generators:
            raise ValueError(f"Unsupported output format: {output_format}. "
                           f"Supported formats: {list(self.generators.keys())}")
        
        generator = self.generators[output_format]
        return generator.generate(log_entries, analysis_results, detailed, source_file)
    
    def get_supported_formats(self) -> List[str]:
        """
        Get list of supported output formats.
        
        Returns:
            List of supported format identifiers
        """
        return list(self.generators.keys()) 