"""
Log File Analyzer and Pattern Detector - Main CLI Application

This module provides both command-line and interactive menu interfaces for the log analysis tool.
It orchestrates the parsing, analysis, and reporting components to provide comprehensive
log file analysis capabilities.

The application supports:
- Command-line usage with arguments
- Interactive menu-driven interface
- Multiple output formats (TXT, JSON, CSV)
- Comprehensive log analysis and pattern detection
- Real-time alerts and recommendations

"""

import argparse
import sys
import os
from datetime import datetime
from typing import Optional

# Import our custom modules
from log_parser import LogParserFactory
from pattern_detector import PatternDetector
from report_generator import ReportGenerator
from utils import validate_file_path, validate_date_format, validate_log_level


class LogAnalyzerCLI:
    """
    Main CLI application class that orchestrates the log analysis process.
    
    This class handles both command-line argument parsing and interactive menu
    interfaces. It coordinates the work between parser, detector, and report generator.
    """
    
    def __init__(self):
        """Initialize the CLI application with argument parser setup."""
        self.parser = self._setup_argument_parser()
        self.log_parser = None
        self.pattern_detector = None
        self.report_generator = None
        self.current_log_file = None
        self.current_analysis_results = None
        self.current_log_entries = None
    
    def _setup_argument_parser(self) -> argparse.ArgumentParser:
        """
        Set up the command-line argument parser with all available options.
        
        Returns:
            argparse.ArgumentParser: Configured argument parser
        """
        parser = argparse.ArgumentParser(
            description="Log File Analyzer and Pattern Detector",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  python log_analyzer.py analyze server.log
  python log_analyzer.py analyze server.log --output json --detailed
  python log_analyzer.py analyze server.log --start-date 2024-01-01 --level ERROR
  python log_analyzer.py menu  # Start interactive menu
            """
        )
        
        # Create subparsers for different commands
        subparsers = parser.add_subparsers(dest='command', help='Available commands')
        
        # Analyze command
        analyze_parser = subparsers.add_parser('analyze', help='Analyze a log file')
        analyze_parser.add_argument('log_file', help='Path to the log file to analyze')
        analyze_parser.add_argument(
            '--output', '-o',
            choices=['txt', 'json', 'csv'],
            default='txt',
            help='Output format for the report (default: txt)'
        )
        analyze_parser.add_argument(
            '--start-date',
            help='Filter logs from this date (YYYY-MM-DD format)'
        )
        analyze_parser.add_argument(
            '--end-date',
            help='Filter logs until this date (YYYY-MM-DD format)'
        )
        analyze_parser.add_argument(
            '--level', '-l',
            choices=['ERROR', 'WARN', 'INFO', 'DEBUG'],
            help='Filter by log level'
        )
        analyze_parser.add_argument(
            '--detailed', '-d',
            action='store_true',
            help='Generate detailed analysis report'
        )
        analyze_parser.add_argument(
            '--threshold', '-t',
            type=int,
            default=10,
            help='Alert threshold for error frequency (default: 10)'
        )
        analyze_parser.add_argument(
            '--output-file',
            help='Save report to specific file (default: prints to console)'
        )
        
        # Menu command
        menu_parser = subparsers.add_parser('menu', help='Start interactive menu interface')

        return parser

    def validate_arguments(self, args) -> bool:
        """Validate all command-line arguments."""
        try:
            # Validate log file path
            if not validate_file_path(args.log_file):
                print(f"Error: Log file '{args.log_file}' does not exist or is not readable.")
                return False
            
            # Validate date formats if provided
            if args.start_date and not validate_date_format(args.start_date):
                print(f"Error: Invalid start date format '{args.start_date}'. Use YYYY-MM-DD format.")
                return False

            if args.end_date and not validate_date_format(args.end_date):
                print(f"Error: Invalid end date format '{args.end_date}'. Use YYYY-MM-DD format.")
                return False

            # Validate date range if both dates are provided
            if args.start_date and args.end_date:
                start = datetime.strptime(args.start_date, '%Y-%m-%d')
                end = datetime.strptime(args.end_date, '%Y-%m-%d')
                if start > end:
                    print("Error: Start date cannot be after end date.")
                    return False

            # Validate threshold
            if args.threshold < 1:
                print("Error: Threshold must be a positive integer.")
                return False

            return True

        except Exception as e:
            print(f"Error during argument validation: {e}")
            return False

    def run(self) -> int:
        """
        Main entry point for the CLI application.
        
        Returns:
            int: Exit code (0 for success, 1 for error)
        """
        try:
            # Parse command-line arguments
            args = self.parser.parse_args()
            
            # Check if a command was provided
            if not args.command:
                self.parser.print_help()
                return 1
            
            # Execute the appropriate command
            if args.command == 'analyze':
                # Validate arguments for analyze command
                if not self.validate_arguments(args):
                    return 1
                return self._analyze_log_file(args)
            elif args.command == 'menu':
                return self._run_interactive_menu()
            else:
                print(f"Unknown command: {args.command}")
                return 1
                
        except KeyboardInterrupt:
            print("\nOperation cancelled by user.")
            return 1
        except Exception as e:
            print(f"Unexpected error: {e}")
            return 1

    def _run_interactive_menu(self) -> int:
        """
        Run the interactive menu-driven interface.
        
        Returns:
            int: Exit code (0 for success, 1 for error)
        """
        print("\n" + "=" * 50)
        print("=== LOG FILE ANALYZER & PATTERN DETECTOR ===")
        print("=" * 50)
        print("Welcome to the Interactive Log Analysis Tool!")
        print("This tool helps you analyze server logs and detect patterns.")
        print()
        
        while True:
            try:
                self._display_main_menu()
                choice = input("\nEnter your choice (1-7): ").strip()
                
                if choice == '1':
                    self._menu_load_log_file()
                elif choice == '2':
                    self._menu_analyze_error_patterns()
                elif choice == '3':
                    self._menu_track_behavior()
                elif choice == '4':
                    self._menu_calculate_performance()
                elif choice == '5':
                    self._menu_generate_alerts()
                elif choice == '6':
                    self._menu_export_analysis()
                elif choice == '7':
                    print("\nThank you for using the Log File Analyzer!")
                    return 0
                else:
                    print("\n❌ Invalid choice. Please enter a number between 1 and 7.")
                    
            except KeyboardInterrupt:
                print("\n\nOperation cancelled by user.")
                return 1
            except Exception as e:
                print(f"\n❌ An error occurred: {e}")
                continue

    def _display_main_menu(self):
        """Display the main menu options."""
        print("\n📋 MAIN MENU")
        print("-" * 30)
        print("1. 📁 Load a log file")
        print("2. 🔍 Analyze error patterns")
        print("3. 📊 Track user/system behavior")
        print("4. ⚡ Calculate performance metrics")
        print("5. 🚨 Generate alert report")
        print("6. 📄 Export full analysis summary")
        print("7. 🚪 Exit")
        print("-" * 30)

    def _menu_load_log_file(self):
        """Menu option 1: Load a log file."""
        print("\n📁 LOAD LOG FILE")
        print("-" * 30)
        
        # Get log file path
        while True:
            log_file = input("Enter the path to your log file: ").strip()
            if not log_file:
                print("❌ Please enter a valid file path.")
                continue
                
            if not validate_file_path(log_file):
                print(f"❌ File '{log_file}' does not exist or is not readable.")
                continue
                
            break
        
        # Parse the log file
        print(f"\n🔄 Loading log file: {log_file}")
        try:
            self.log_parser = LogParserFactory.create_parser(log_file)
            self.current_log_entries = self.log_parser.parse_file()
            self.current_log_file = log_file
            
            if not self.current_log_entries:
                print("❌ No log entries found in the file.")
                return
                
            print(f"✅ Successfully loaded {len(self.current_log_entries)} log entries!")
            print(f"📊 Log format detected: {self.log_parser.get_format_name()}")
            
        except Exception as e:
            print(f"❌ Error loading log file: {e}")

    def _menu_analyze_error_patterns(self):
        """Menu option 2: Analyze error patterns."""
        if not self.current_log_entries:
            print("\n❌ Please load a log file first (Option 1).")
            return
            
        print("\n🔍 ANALYZE ERROR PATTERNS")
        print("-" * 30)
        
        # Get analysis parameters
        threshold = self._get_threshold_input()
        
        print(f"\n🔄 Analyzing error patterns with threshold: {threshold}")
        try:
            self.pattern_detector = PatternDetector(threshold=threshold)
            self.current_analysis_results = self.pattern_detector.analyze(self.current_log_entries)
            
            # Display error analysis results
            print("\n📊 ERROR ANALYSIS RESULTS")
            print("-" * 30)
            print(f"Total entries analyzed: {self.current_analysis_results.total_entries}")
            print(f"Total requests: {self.current_analysis_results.total_requests}")
            print(f"Error count: {self.current_analysis_results.error_count}")
            print(f"Error rate: {self.current_analysis_results.error_rate:.2%}")
            
            if self.current_analysis_results.status_code_distribution:
                print("\nStatus Code Distribution:")
                for code, count in sorted(self.current_analysis_results.status_code_distribution.items()):
                    print(f"  {code}: {count} requests")
            
            if self.current_analysis_results.repeated_errors:
                print("\n🚨 Repeated Errors:")
                for error in self.current_analysis_results.repeated_errors[:5]:  # Show top 5
                    print(f"  {error['status_code']} on {error['endpoint']}: {error['count']} times")
                    
        except Exception as e:
            print(f"❌ Error during analysis: {e}")

    def _menu_track_behavior(self):
        """Menu option 3: Track user/system behavior."""
        if not self.current_analysis_results:
            print("\n❌ Please analyze error patterns first (Option 2).")
            return
            
        print("\n📊 USER/SYSTEM BEHAVIOR ANALYSIS")
        print("-" * 30)
        
        try:
            # Display traffic analysis
            if self.current_analysis_results.hourly_traffic:
                print("\n🕐 Hourly Traffic Pattern:")
                peak_hour = max(self.current_analysis_results.hourly_traffic.items(), key=lambda x: x[1])
                print(f"  Peak hour: {peak_hour[0]}:00 with {peak_hour[1]} requests")
            
            if self.current_analysis_results.daily_traffic:
                print("\n📅 Daily Traffic Pattern:")
                peak_day = max(self.current_analysis_results.daily_traffic.items(), key=lambda x: x[1])
                print(f"  Peak day: {peak_day[0]} with {peak_day[1]} requests")
            
            if self.current_analysis_results.top_endpoints:
                print("\n🔗 Top Endpoints:")
                for endpoint, count in self.current_analysis_results.top_endpoints[:5]:
                    print(f"  {endpoint}: {count} requests")
            
            if self.current_analysis_results.top_user_agents:
                print("\n🌐 Top User Agents:")
                for agent, count in self.current_analysis_results.top_user_agents[:3]:
                    print(f"  {agent[:50]}...: {count} requests")
            
            if self.current_analysis_results.suspicious_ips:
                print("\n⚠️ Suspicious IP Addresses:")
                for ip_info in self.current_analysis_results.suspicious_ips[:3]:
                    print(f"  {ip_info['ip']}: {ip_info['error_count']} errors")
                    
        except Exception as e:
            print(f"❌ Error during behavior analysis: {e}")

    def _menu_calculate_performance(self):
        """Menu option 4: Calculate performance metrics."""
        if not self.current_analysis_results:
            print("\n❌ Please analyze error patterns first (Option 2).")
            return
            
        print("\n⚡ PERFORMANCE METRICS")
        print("-" * 30)
        
        try:
            if self.current_analysis_results.response_time_stats:
                stats = self.current_analysis_results.response_time_stats
                print(f"\n📈 Response Time Statistics:")
                print(f"  Average: {stats.get('mean', 'N/A'):.2f} ms")
                print(f"  Median: {stats.get('median', 'N/A'):.2f} ms")
                print(f"  Minimum: {stats.get('min', 'N/A'):.2f} ms")
                print(f"  Maximum: {stats.get('max', 'N/A'):.2f} ms")
            
            if self.current_analysis_results.slow_requests:
                print(f"\n🐌 Slow Requests (>1000ms): {len(self.current_analysis_results.slow_requests)}")
                for request in self.current_analysis_results.slow_requests[:3]:
                    print(f"  {request['method']} {request['path']}: {request['response_time']:.2f} ms")
            
            if self.current_analysis_results.peak_usage_periods:
                print(f"\n📊 Peak Usage Periods: {len(self.current_analysis_results.peak_usage_periods)} detected")
                for period in self.current_analysis_results.peak_usage_periods[:3]:
                    print(f"  {period['start_time']} - {period['end_time']}: {period['request_count']} requests")
                    
        except Exception as e:
            print(f"❌ Error during performance analysis: {e}")

    def _menu_generate_alerts(self):
        """Menu option 5: Generate alert report."""
        if not self.current_analysis_results:
            print("\n❌ Please analyze error patterns first (Option 2).")
            return
            
        print("\n🚨 ALERT REPORT")
        print("-" * 30)
        
        try:
            if not self.current_analysis_results.alerts:
                print("✅ No critical alerts detected!")
                return
                
            print(f"🚨 {len(self.current_analysis_results.alerts)} alerts generated:")
            for i, alert in enumerate(self.current_analysis_results.alerts, 1):
                severity_icon = "🔴" if alert['severity'] == 'high' else "🟡" if alert['severity'] == 'medium' else "🟢"
                print(f"\n{i}. {severity_icon} {alert['message']}")
                if 'details' in alert:
                    details = alert['details']
                    if isinstance(details, dict):
                        for key, value in details.items():
                            print(f"   {key}: {value}")
                            
        except Exception as e:
            print(f"❌ Error generating alerts: {e}")

    def _menu_export_analysis(self):
        """Menu option 6: Export full analysis summary."""
        if not self.current_analysis_results:
            print("\n❌ Please analyze error patterns first (Option 2).")
            return
            
        print("\n📄 EXPORT ANALYSIS SUMMARY")
        print("-" * 30)
        
        # Get export parameters
        print("Available output formats:")
        print("1. Text (human-readable)")
        print("2. JSON (structured data)")
        print("3. CSV (spreadsheet)")
        
        while True:
            format_choice = input("\nSelect output format (1-3): ").strip()
            if format_choice in ['1', '2', '3']:
                break
            print("❌ Please enter 1, 2, or 3.")
        
        format_map = {'1': 'txt', '2': 'json', '3': 'csv'}
        output_format = format_map[format_choice]
        
        # Ask for detailed report
        detailed_choice = input("\nGenerate detailed report? (y/n): ").strip().lower()
        detailed = detailed_choice in ['y', 'yes']
        
        # Ask for file output
        save_to_file = input("\nSave to file? (y/n): ").strip().lower() in ['y', 'yes']
        output_file = None
        if save_to_file:
            default_name = f"log_analysis_report.{output_format}"
            output_file = input(f"Enter filename (default: {default_name}): ").strip()
            if not output_file:
                output_file = default_name
        
        print(f"\n🔄 Generating {output_format.upper()} report...")
        try:
            self.report_generator = ReportGenerator()
            report = self.report_generator.generate_report(
                log_entries=self.current_log_entries,
                analysis_results=self.current_analysis_results,
                output_format=output_format,
                detailed=detailed,
                source_file=self.current_log_file
            )
            
            if output_file:
                # Save to file
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(report)
                print(f"✅ Report saved to: {output_file}")
            else:
                # Print to console
                print("\n" + "=" * 50)
                print("ANALYSIS REPORT")
                print("=" * 50)
                print(report)
                
        except Exception as e:
            print(f"❌ Error generating report: {e}")

    def _get_threshold_input(self) -> int:
        """Get threshold input from user."""
        while True:
            try:
                threshold_input = input("Enter alert threshold (default: 10): ").strip()
                if not threshold_input:
                    return 10
                threshold = int(threshold_input)
                if threshold < 1:
                    print("❌ Threshold must be a positive integer.")
                    continue
                return threshold
            except ValueError:
                print("❌ Please enter a valid number.")

    def _analyze_log_file(self, args) -> int:
        """
        Perform log file analysis with the given arguments.
        
        Args:
            args: Parsed command-line arguments
            
        Returns:
            int: Exit code (0 for success, 1 for error)
        """
        try:
            print(f"Analyzing log file: {args.log_file}")
            print("=" * 50)
            
            # Step 1: Parse the log file
            print("Step 1: Parsing log file...")
            self.log_parser = LogParserFactory.create_parser(args.log_file)
            log_entries = self.log_parser.parse_file(
                start_date=args.start_date,
                end_date=args.end_date,
                level=args.level
            )
            
            if not log_entries:
                print("No log entries found matching the specified criteria.")
                return 0
            
            print(f"Parsed {len(log_entries)} log entries.")
            
            # Step 2: Detect patterns and analyze
            print("Step 2: Detecting patterns and analyzing data...")
            self.pattern_detector = PatternDetector(threshold=args.threshold)
            analysis_results = self.pattern_detector.analyze(log_entries)
            
            # Step 3: Generate report
            print("Step 3: Generating analysis report...")
            self.report_generator = ReportGenerator()
            report = self.report_generator.generate_report(
                log_entries=log_entries,
                analysis_results=analysis_results,
                output_format=args.output,
                detailed=args.detailed,
                source_file=args.log_file
            )
            
            # Step 4: Output the report
            if args.output_file:
                # Save to file
                try:
                    with open(args.output_file, 'w', encoding='utf-8') as f:
                        f.write(report)
                    print(f"Report saved to: {args.output_file}")
                except IOError as e:
                    print(f"Error saving report to file: {e}")
                    return 1
            else:
                # Print to console
                print("\n" + "=" * 50)
                print("ANALYSIS REPORT")
                print("=" * 50)
                print(report)
            
            print("\nAnalysis completed successfully!")
            return 0
            
        except Exception as e:
            print(f"Error during analysis: {e}")
            return 1


def main():
    """
    Main entry point for the application.
    
    This function creates the CLI application and runs it,
    returning the appropriate exit code.
    """
    cli = LogAnalyzerCLI()
    return cli.run()


if __name__ == "__main__":
    sys.exit(main()) 