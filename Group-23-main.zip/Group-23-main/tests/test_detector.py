"""
Unit Tests for Pattern Detector Module

This module contains comprehensive unit tests for the pattern detection functionality,
including tests for error detection, performance analysis, and anomaly detection.

The tests cover:
- Error pattern detection
- Performance analysis
- Security analysis
- Traffic analysis
- Anomaly detection
- Alert generation

"""

import unittest
from datetime import datetime, timedelta
from unittest.mock import Mock

# Import the modules to test
from pattern_detector import PatternDetector, AnalysisResult
from log_parser import LogEntry


class TestPatternDetector(unittest.TestCase):
    """Test cases for pattern detector functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.detector = PatternDetector(threshold=5)
        
        # Create sample log entries for testing
        self.sample_entries = [
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 0, 0),
                level="INFO",
                message="GET /api/users - 200",
                ip_address="192.168.1.100",
                status_code=200,
                response_time=150.0,
                request_method="GET",
                request_path="/api/users"
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 1, 0),
                level="ERROR",
                message="GET /api/users - 500",
                ip_address="192.168.1.101",
                status_code=500,
                response_time=2000.0,
                request_method="GET",
                request_path="/api/users"
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 2, 0),
                level="WARN",
                message="GET /api/users - 404",
                ip_address="192.168.1.102",
                status_code=404,
                response_time=100.0,
                request_method="GET",
                request_path="/api/users"
            )
        ]
    
    def test_analyze_empty_entries(self):
        """Test analysis with empty log entries."""
        result = self.detector.analyze([])
        
        self.assertEqual(result.total_entries, 0)
        self.assertEqual(result.total_requests, 0)
        self.assertEqual(result.error_count, 0)
        self.assertEqual(result.error_rate, 0.0)
        self.assertEqual(len(result.recommendations), 1)
        self.assertIn("No log entries to analyze", result.recommendations)
    
    def test_analyze_basic_statistics(self):
        """Test basic statistics calculation."""
        result = self.detector.analyze(self.sample_entries)
        
        self.assertEqual(result.total_entries, 3)
        self.assertEqual(result.total_requests, 3)
        self.assertEqual(result.error_count, 2)  # ERROR + WARN
        self.assertAlmostEqual(result.error_rate, 2/3, places=2)
        self.assertEqual(result.average_response_time, 750.0)  # (150 + 2000 + 100) / 3
    
    def test_analyze_errors(self):
        """Test error analysis functionality."""
        # Create entries with repeated errors
        error_entries = []
        for i in range(10):  # Create 10 repeated 500 errors
            error_entries.append(LogEntry(
                timestamp=datetime(2024, 1, 15, 10, i, 0),
                level="ERROR",
                message="GET /api/users - 500",
                ip_address="192.168.1.100",
                status_code=500,
                request_method="GET",
                request_path="/api/users"
            ))
        
        result = self.detector.analyze(error_entries)
        
        self.assertEqual(result.error_count, 10)
        self.assertEqual(result.error_rate, 1.0)
        self.assertEqual(len(result.repeated_errors), 1)
        self.assertEqual(result.repeated_errors[0]['count'], 10)
        self.assertEqual(result.repeated_errors[0]['status_code'], 500)
    
    def test_analyze_performance(self):
        """Test performance analysis functionality."""
        # Create entries with various response times
        performance_entries = [
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 0, 0),
                level="INFO",
                message="Fast request",
                status_code=200,
                response_time=50.0
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 1, 0),
                level="INFO",
                message="Slow request",
                status_code=200,
                response_time=1500.0
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 2, 0),
                level="INFO",
                message="Medium request",
                status_code=200,
                response_time=300.0
            )
        ]
        
        result = self.detector.analyze(performance_entries)
        
        self.assertIsNotNone(result.response_time_stats)
        stats = result.response_time_stats
        self.assertEqual(stats['min'], 50.0)
        self.assertEqual(stats['max'], 1500.0)
        self.assertAlmostEqual(stats['mean'], 616.67, places=2)  # (50 + 1500 + 300) / 3
        self.assertEqual(stats['median'], 300.0)
        
        # Check slow requests detection
        self.assertEqual(len(result.slow_requests), 1)
        self.assertEqual(result.slow_requests[0]['response_time'], 1500.0)
    
    def test_analyze_security(self):
        """Test security analysis functionality."""
        # Create entries with suspicious activity
        security_entries = [
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 0, 0),
                level="ERROR",
                message="Failed login attempt",
                ip_address="192.168.1.100",
                status_code=401,
                request_path="/login"
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 1, 0),
                level="ERROR",
                message="Failed login attempt",
                ip_address="192.168.1.100",
                status_code=401,
                request_path="/login"
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 2, 0),
                level="ERROR",
                message="Failed login attempt",
                ip_address="192.168.1.100",
                status_code=401,
                request_path="/login"
            )
        ]
        
        result = self.detector.analyze(security_entries)
        
        # Check suspicious IP detection (100% error rate)
        self.assertEqual(len(result.suspicious_ips), 1)
        self.assertEqual(result.suspicious_ips[0]['ip_address'], '192.168.1.100')
        self.assertEqual(result.suspicious_ips[0]['error_rate'], 1.0)
    
    def test_analyze_traffic(self):
        """Test traffic analysis functionality."""
        # Create entries with different timestamps
        traffic_entries = []
        for i in range(24):  # Create entries for each hour
            for j in range(10):  # 10 requests per hour
                traffic_entries.append(LogEntry(
                    timestamp=datetime(2024, 1, 15, i, j, 0),
                    level="INFO",
                    message="Request",
                    status_code=200,
                    request_path="/api/test",
                    user_agent="Mozilla/5.0"
                ))
        
        result = self.detector.analyze(traffic_entries)
        
        # Check hourly traffic
        self.assertEqual(len(result.hourly_traffic), 24)
        for hour in range(24):
            self.assertEqual(result.hourly_traffic[hour], 10)
        
        # Check daily traffic
        self.assertEqual(len(result.daily_traffic), 1)
        self.assertEqual(result.daily_traffic['2024-01-15'], 240)
        
        # Check top endpoints
        self.assertEqual(len(result.top_endpoints), 1)
        self.assertEqual(result.top_endpoints[0][0], '/api/test')
        self.assertEqual(result.top_endpoints[0][1], 240)
    
    def test_detect_anomalies(self):
        """Test anomaly detection functionality."""
        # Create entries with unusual traffic pattern
        anomaly_entries = []
        
        # Normal traffic (10 requests per hour)
        for i in range(10):
            anomaly_entries.append(LogEntry(
                timestamp=datetime(2024, 1, 15, 10, i, 0),
                level="INFO",
                message="Normal request",
                status_code=200
            ))
        
        # Unusual high traffic (50 requests in one hour)
        for i in range(50):
            anomaly_entries.append(LogEntry(
                timestamp=datetime(2024, 1, 15, 11, i, 0),
                level="INFO",
                message="High traffic request",
                status_code=200
            ))
        
        result = self.detector.analyze(anomaly_entries)
        
        # Should detect anomalies (may not always detect due to statistical thresholds)
        # Check for unusual traffic anomaly
        traffic_anomalies = [a for a in result.anomalies if a['type'] == 'unusual_traffic']
        # Note: Anomaly detection depends on statistical thresholds and may not always trigger
    
    def test_generate_alerts(self):
        """Test alert generation functionality."""
        # Create entries that should trigger alerts
        alert_entries = []
        
        # High error rate
        for i in range(20):
            alert_entries.append(LogEntry(
                timestamp=datetime(2024, 1, 15, 10, i, 0),
                level="ERROR" if i < 10 else "INFO",  # 50% error rate
                message="Request",
                status_code=500 if i < 10 else 200
            ))
        
        result = self.detector.analyze(alert_entries)
        
        # Should generate alerts
        self.assertGreater(len(result.alerts), 0)
        
        # Check for high error rate alert
        error_alerts = [a for a in result.alerts if a['type'] == 'high_error_rate']
        self.assertGreater(len(error_alerts), 0)
    
    def test_generate_recommendations(self):
        """Test recommendation generation functionality."""
        # Create entries with various issues
        recommendation_entries = [
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 0, 0),
                level="ERROR",
                message="Server error",
                status_code=500,
                response_time=2000.0
            ),
            LogEntry(
                timestamp=datetime(2024, 1, 15, 10, 1, 0),
                level="ERROR",
                message="Server error",
                status_code=500,
                response_time=2000.0
            )
        ]
        
        result = self.detector.analyze(recommendation_entries)
        
        # Should generate recommendations
        self.assertGreater(len(result.recommendations), 0)
        
        # Check for specific recommendations
        recommendations_text = " ".join(result.recommendations).lower()
        self.assertIn("error", recommendations_text)
    
    def test_threshold_configuration(self):
        """Test that threshold configuration works correctly."""
        # Test with different thresholds
        detector_low = PatternDetector(threshold=2)
        detector_high = PatternDetector(threshold=10)
        
        # Create entries with repeated errors
        repeated_entries = []
        for i in range(5):
            repeated_entries.append(LogEntry(
                timestamp=datetime(2024, 1, 15, 10, i, 0),
                level="ERROR",
                message="Repeated error",
                status_code=500,
                request_path="/api/test"
            ))
        
        result_low = detector_low.analyze(repeated_entries)
        result_high = detector_high.analyze(repeated_entries)
        
        # Low threshold should detect repeated errors
        self.assertGreater(len(result_low.repeated_errors), 0)
        
        # High threshold should not detect repeated errors (only 5 occurrences)
        self.assertEqual(len(result_high.repeated_errors), 0)


class TestAnalysisResult(unittest.TestCase):
    """Test cases for AnalysisResult data class."""
    
    def test_analysis_result_creation(self):
        """Test creating an AnalysisResult with all fields."""
        result = AnalysisResult(
            total_entries=100,
            total_requests=95,
            average_response_time=250.0,
            error_count=5,
            error_rate=0.05,
            status_code_distribution={200: 90, 404: 3, 500: 2},
            repeated_errors=[],
            response_time_stats={'mean': 250.0, 'max': 1000.0},
            peak_usage_periods=[],
            slow_requests=[],
            suspicious_ips=[],
            failed_logins=[],
            hourly_traffic={},
            daily_traffic={},
            top_endpoints=[],
            top_user_agents=[],
            anomalies=[],
            alerts=[],
            recommendations=["Test recommendation"]
        )
        
        self.assertEqual(result.total_entries, 100)
        self.assertEqual(result.total_requests, 95)
        self.assertEqual(result.average_response_time, 250.0)
        self.assertEqual(result.error_count, 5)
        self.assertEqual(result.error_rate, 0.05)
        self.assertEqual(len(result.recommendations), 1)
    
    def test_analysis_result_empty(self):
        """Test creating an empty AnalysisResult."""
        result = AnalysisResult(
            total_entries=0,
            total_requests=0,
            average_response_time=None,
            error_count=0,
            error_rate=0.0,
            status_code_distribution={},
            repeated_errors=[],
            response_time_stats={},
            peak_usage_periods=[],
            slow_requests=[],
            suspicious_ips=[],
            failed_logins=[],
            hourly_traffic={},
            daily_traffic={},
            top_endpoints=[],
            top_user_agents=[],
            anomalies=[],
            alerts=[],
            recommendations=[]
        )
        
        self.assertEqual(result.total_entries, 0)
        self.assertIsNone(result.average_response_time)
        self.assertEqual(result.error_rate, 0.0)


if __name__ == '__main__':
    # Run the tests
    unittest.main(verbosity=2) 