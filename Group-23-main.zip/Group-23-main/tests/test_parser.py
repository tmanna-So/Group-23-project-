"""
Unit Tests for Log Parser Module

This module contains comprehensive unit tests for the log parser functionality,
including tests for pattern matching, parsing logic, and error handling.

The tests cover:
- Apache log parsing
- Nginx log parsing
- Generic log parsing
- Factory pattern functionality
- Error handling and edge cases

"""

import unittest
import tempfile
import os
from datetime import datetime
from unittest.mock import patch, mock_open

# Import the modules to test
from log_parser import (
    ApacheLogParser, NginxLogParser, GenericLogParser,
    LogParserFactory, LogEntry, BaseLogParser
)


class TestApacheLogParser(unittest.TestCase):
    """Test cases for Apache log parser functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.parser = ApacheLogParser("test.log")
    
    def test_parse_combined_format(self):
        """Test parsing Apache Combined Log Format."""
        log_line = '192.168.1.100 - - [25/Dec/2023:10:30:45 +0000] "GET /api/users HTTP/1.1" 200 1234 "https://example.com" "Mozilla/5.0"'
        
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.ip_address, '192.168.1.100')
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.request_method, 'GET')
        self.assertEqual(result.request_path, '/api/users')
        self.assertEqual(result.bytes_sent, 1234)
        self.assertEqual(result.referer, 'https://example.com')
        self.assertEqual(result.user_agent, 'Mozilla/5.0')
        self.assertEqual(result.level, 'INFO')
    
    def test_parse_common_format(self):
        """Test parsing Apache Common Log Format."""
        log_line = '192.168.1.100 - - [25/Dec/2023:10:30:45 +0000] "GET /api/users HTTP/1.1" 200 1234'
        
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.ip_address, '192.168.1.100')
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.request_method, 'GET')
        self.assertEqual(result.request_path, '/api/users')
        self.assertEqual(result.bytes_sent, 1234)
        self.assertIsNone(result.referer)
        self.assertIsNone(result.user_agent)
    
    def test_parse_error_status_codes(self):
        """Test that error status codes are correctly classified."""
        # Test 404 error
        log_line = '192.168.1.100 - - [25/Dec/2023:10:30:45 +0000] "GET /nonexistent HTTP/1.1" 404 1234'
        result = self.parser.parse_line(log_line)
        self.assertEqual(result.level, 'WARN')
        
        # Test 500 error
        log_line = '192.168.1.100 - - [25/Dec/2023:10:30:45 +0000] "GET /api/users HTTP/1.1" 500 1234'
        result = self.parser.parse_line(log_line)
        self.assertEqual(result.level, 'ERROR')
    
    def test_parse_invalid_line(self):
        """Test parsing invalid log line returns None."""
        invalid_line = "This is not a valid Apache log line"
        result = self.parser.parse_line(invalid_line)
        self.assertIsNone(result)
    
    def test_parse_timestamp_without_timezone(self):
        """Test parsing timestamp without timezone information."""
        log_line = '192.168.1.100 - - [25/Dec/2023:10:30:45] "GET /api/users HTTP/1.1" 200 1234'
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertIsInstance(result.timestamp, datetime)
    
    def test_get_format_name(self):
        """Test that the format name is correctly returned."""
        self.assertEqual(self.parser.get_format_name(), "Apache")


class TestNginxLogParser(unittest.TestCase):
    """Test cases for Nginx log parser functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.parser = NginxLogParser("test.log")
    
    def test_parse_nginx_format(self):
        """Test parsing Nginx log format."""
        log_line = '192.168.1.100 - user [25/Dec/2023:10:30:45 +0000] "GET /api/users HTTP/1.1" 200 1234 "https://example.com" "Mozilla/5.0" "-"'
        
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.ip_address, '192.168.1.100')
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.request_method, 'GET')
        self.assertEqual(result.request_path, '/api/users')
        self.assertEqual(result.bytes_sent, 1234)
        self.assertEqual(result.referer, 'https://example.com')
        self.assertEqual(result.user_agent, 'Mozilla/5.0')
    
    def test_parse_invalid_nginx_line(self):
        """Test parsing invalid Nginx log line returns None."""
        invalid_line = "This is not a valid Nginx log line"
        result = self.parser.parse_line(invalid_line)
        self.assertIsNone(result)
    
    def test_get_format_name(self):
        """Test that the format name is correctly returned."""
        self.assertEqual(self.parser.get_format_name(), "Nginx")


class TestGenericLogParser(unittest.TestCase):
    """Test cases for generic log parser functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.parser = GenericLogParser("test.log")
    
    def test_parse_standard_timestamp_format(self):
        """Test parsing log line with standard timestamp format."""
        log_line = "2024-01-15 14:30:45 [INFO] User login successful from 192.168.1.100"
        
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.level, 'INFO')
        self.assertEqual(result.ip_address, '192.168.1.100')
        self.assertIsInstance(result.timestamp, datetime)
    
    def test_parse_alternative_timestamp_format(self):
        """Test parsing log line with alternative timestamp format."""
        log_line = "01/15/2024 14:30:45 [ERROR] Database connection failed"
        
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.level, 'ERROR')
        self.assertIsInstance(result.timestamp, datetime)
    
    def test_parse_line_without_timestamp(self):
        """Test parsing line without timestamp returns None."""
        log_line = "This line has no timestamp"
        result = self.parser.parse_line(log_line)
        self.assertIsNone(result)
    
    def test_extract_ip_address(self):
        """Test IP address extraction from log line."""
        log_line = "2024-01-15 14:30:45 [INFO] Request from 10.0.0.1 processed"
        result = self.parser.parse_line(log_line)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.ip_address, '10.0.0.1')
    
    def test_get_format_name(self):
        """Test that the format name is correctly returned."""
        self.assertEqual(self.parser.get_format_name(), "Generic")


class TestLogParserFactory(unittest.TestCase):
    """Test cases for log parser factory functionality."""
    
    def test_create_apache_parser(self):
        """Test factory creates Apache parser for Apache format."""
        with patch('builtins.open', mock_open(read_data='192.168.1.100 - - [25/Dec/2023:10:30:45 +0000] "GET / HTTP/1.1" 200 1234')):
            parser = LogParserFactory.create_parser("apache.log")
            self.assertIsInstance(parser, ApacheLogParser)
    
    def test_create_nginx_parser(self):
        """Test factory creates Nginx parser for Nginx format."""
        with patch('builtins.open', mock_open(read_data='192.168.1.100 - user [25/Dec/2023:10:30:45 +0000] "GET / HTTP/1.1" 200 1234 "referer" "user-agent" "-"')):
            parser = LogParserFactory.create_parser("nginx.log")
            self.assertIsInstance(parser, NginxLogParser)
    
    def test_create_generic_parser(self):
        """Test factory creates generic parser for unknown format."""
        with patch('builtins.open', mock_open(read_data='2024-01-15 14:30:45 [INFO] Generic log entry')):
            parser = LogParserFactory.create_parser("unknown.log")
            self.assertIsInstance(parser, GenericLogParser)
    
    def test_create_parser_with_file_error(self):
        """Test factory handles file reading errors gracefully."""
        with patch('builtins.open', side_effect=FileNotFoundError()):
            parser = LogParserFactory.create_parser("nonexistent.log")
            self.assertIsInstance(parser, GenericLogParser)


class TestLogEntry(unittest.TestCase):
    """Test cases for LogEntry data class."""
    
    def test_log_entry_creation(self):
        """Test creating a LogEntry with all fields."""
        timestamp = datetime.now()
        entry = LogEntry(
            timestamp=timestamp,
            level="INFO",
            message="Test message",
            ip_address="192.168.1.100",
            status_code=200,
            response_time=150.5,
            request_method="GET",
            request_path="/api/test",
            user_agent="Mozilla/5.0",
            bytes_sent=1024,
            referer="https://example.com",
            raw_line="Original log line"
        )
        
        self.assertEqual(entry.timestamp, timestamp)
        self.assertEqual(entry.level, "INFO")
        self.assertEqual(entry.message, "Test message")
        self.assertEqual(entry.ip_address, "192.168.1.100")
        self.assertEqual(entry.status_code, 200)
        self.assertEqual(entry.response_time, 150.5)
        self.assertEqual(entry.request_method, "GET")
        self.assertEqual(entry.request_path, "/api/test")
        self.assertEqual(entry.user_agent, "Mozilla/5.0")
        self.assertEqual(entry.bytes_sent, 1024)
        self.assertEqual(entry.referer, "https://example.com")
        self.assertEqual(entry.raw_line, "Original log line")
    
    def test_log_entry_minimal_creation(self):
        """Test creating a LogEntry with minimal required fields."""
        timestamp = datetime.now()
        entry = LogEntry(
            timestamp=timestamp,
            level="ERROR",
            message="Error message"
        )
        
        self.assertEqual(entry.timestamp, timestamp)
        self.assertEqual(entry.level, "ERROR")
        self.assertEqual(entry.message, "Error message")
        self.assertIsNone(entry.ip_address)
        self.assertIsNone(entry.status_code)
        self.assertEqual(entry.raw_line, "")


class TestBaseLogParser(unittest.TestCase):
    """Test cases for base log parser functionality."""
    
    def test_abstract_class_cannot_be_instantiated(self):
        """Test that BaseLogParser cannot be instantiated directly."""
        with self.assertRaises(TypeError):
            BaseLogParser("test.log")
    
    def test_passes_filters(self):
        """Test filter logic in base parser."""
        # Create a concrete parser for testing
        parser = ApacheLogParser("test.log")
        
        # Create a test log entry
        timestamp = datetime(2024, 1, 15, 14, 30, 45)
        entry = LogEntry(
            timestamp=timestamp,
            level="INFO",
            message="Test message"
        )
        
        # Test date range filtering
        start_dt = datetime(2024, 1, 14)
        end_dt = datetime(2024, 1, 16)
        
        # Should pass filters
        self.assertTrue(parser._passes_filters(entry, start_dt, end_dt, None))
        
        # Should fail date filter
        self.assertFalse(parser._passes_filters(entry, datetime(2024, 1, 16), None, None))
        
        # Should fail level filter
        self.assertFalse(parser._passes_filters(entry, None, None, "ERROR"))


if __name__ == '__main__':
    # Run the tests
    unittest.main(verbosity=2) 