"""
Log Parser Module - Core parsing logic for different log formats

This module provides the foundation for parsing various log file formats.
It uses object-oriented programming with inheritance and polymorphism to
support different log formats while maintaining a consistent interface.

The module includes:
- Abstract base class for log parsers
- Concrete implementations for Apache and Nginx logs
- Factory pattern for automatic parser selection
- Robust error handling and validation

"""

import re
import os
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Dict, Optional, Any
from dataclasses import dataclass


@dataclass
class LogEntry:
    """
    Data class representing a parsed log entry.
    
    This class encapsulates all the information extracted from a single
    log line, providing a consistent structure for downstream processing.
    """
    timestamp: datetime
    level: str
    message: str
    ip_address: Optional[str] = None
    status_code: Optional[int] = None
    response_time: Optional[float] = None
    request_method: Optional[str] = None
    request_path: Optional[str] = None
    user_agent: Optional[str] = None
    bytes_sent: Optional[int] = None
    referer: Optional[str] = None
    raw_line: str = ""


class BaseLogParser(ABC):
    """
    Abstract base class for log parsers.
    
    This class defines the interface that all log parsers must implement.
    It enforces consistency across different log format parsers while
    allowing for format-specific parsing logic.
    """
    
    def __init__(self, file_path: str):
        """
        Initialize the parser with a file path.
        
        Args:
            file_path: Path to the log file to parse
        """
        self.file_path = file_path
        self.line_count = 0
        self.error_count = 0
    
    @abstractmethod
    def parse_line(self, line: str) -> Optional[LogEntry]:
        """
        Parse a single log line into a LogEntry object.
        
        This is the core parsing method that each concrete parser must implement.
        It should extract all relevant information from the log line and return
        a structured LogEntry object.
        
        Args:
            line: Raw log line to parse
            
        Returns:
            LogEntry object if parsing successful, None if line should be skipped
        """
        pass
    
    @abstractmethod
    def get_format_name(self) -> str:
        """
        Return the name of the log format this parser handles.
        
        Returns:
            String identifier for the log format
        """
        pass
    
    def parse_file(self, 
                   start_date: Optional[str] = None,
                   end_date: Optional[str] = None,
                   level: Optional[str] = None) -> List[LogEntry]:
        """
        Parse the entire log file with optional filtering.
        
        This method reads the file line by line, applies filters, and returns
        a list of parsed log entries. It includes comprehensive error handling
        and progress tracking.
        
        Args:
            start_date: Filter entries from this date (YYYY-MM-DD)
            end_date: Filter entries until this date (YYYY-MM-DD)
            level: Filter by log level (ERROR, WARN, INFO, DEBUG)
            
        Returns:
            List of LogEntry objects that match the filter criteria
            
        Raises:
            FileNotFoundError: If the log file doesn't exist
            PermissionError: If the file cannot be read
        """
        log_entries = []
        
        # Convert date strings to datetime objects for comparison
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        try:
            with open(self.file_path, 'r', encoding='utf-8', errors='ignore') as file:
                for line_num, line in enumerate(file, 1):
                    self.line_count += 1
                    
                    # Skip empty lines
                    if not line.strip():
                        continue
                    
                    try:
                        # Parse the line
                        entry = self.parse_line(line.strip())
                        
                        if entry is None:
                            continue  # Line was intentionally skipped
                        
                        # Apply filters
                        if not self._passes_filters(entry, start_dt, end_dt, level):
                            continue
                        
                        log_entries.append(entry)
                        
                    except Exception as e:
                        self.error_count += 1
                        # Log parsing errors but continue processing
                        print(f"Warning: Error parsing line {line_num}: {e}")
                        continue
            
            print(f"Parsing complete: {len(log_entries)} entries processed, "
                  f"{self.error_count} errors encountered")
            
            return log_entries
            
        except FileNotFoundError:
            raise FileNotFoundError(f"Log file not found: {self.file_path}")
        except PermissionError:
            raise PermissionError(f"Cannot read log file: {self.file_path}")
        except Exception as e:
            raise Exception(f"Unexpected error reading log file: {e}")
    
    def _passes_filters(self, entry: LogEntry, 
                       start_dt: Optional[datetime],
                       end_dt: Optional[datetime],
                       level: Optional[str]) -> bool:
        """
        Check if a log entry passes all applied filters.
        
        Args:
            entry: LogEntry to check
            start_dt: Start date filter
            end_dt: End date filter
            level: Log level filter
            
        Returns:
            True if entry passes all filters, False otherwise
        """
        # Date range filter
        if start_dt and entry.timestamp.date() < start_dt.date():
            return False
        if end_dt and entry.timestamp.date() > end_dt.date():
            return False
        
        # Level filter
        if level and entry.level.upper() != level.upper():
            return False
        
        return True


class ApacheLogParser(BaseLogParser):
    """
    Parser for Apache web server log files.
    
    This parser handles the Common Log Format (CLF) and Combined Log Format
    used by Apache web servers. It can automatically detect the format and
    extract relevant information including IP addresses, timestamps, status
    codes, and request details.
    """
    
    # Regular expressions for different Apache log formats
    CLF_PATTERN = re.compile(
        r'^(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d+) (\d+)$'
    )
    
    COMBINED_PATTERN = re.compile(
        r'^(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d+) (\d+) "([^"]*)" "([^"]*)"$'
    )
    
    # Pattern to extract request method and path from request string
    REQUEST_PATTERN = re.compile(r'^(\S+) (\S+) (\S+)$')
    
    def parse_line(self, line: str) -> Optional[LogEntry]:
        """
        Parse an Apache log line into a LogEntry object.
        
        Args:
            line: Raw Apache log line
            
        Returns:
            LogEntry object if parsing successful, None if line should be skipped
        """
        # Try Combined Log Format first (more detailed)
        match = self.COMBINED_PATTERN.match(line)
        if match:
            return self._parse_combined_format(match, line)
        
        # Try Common Log Format
        match = self.CLF_PATTERN.match(line)
        if match:
            return self._parse_common_format(match, line)
        
        # If no pattern matches, skip the line
        return None
    
    def _parse_combined_format(self, match, line: str) -> LogEntry:
        """Parse Combined Log Format line."""
        ip_address = match.group(1)
        timestamp_str = match.group(2)
        request_str = match.group(3)
        status_code = int(match.group(4))
        bytes_sent = int(match.group(5))
        referer = match.group(6)
        user_agent = match.group(7)
        
        # Parse timestamp
        timestamp = self._parse_apache_timestamp(timestamp_str)
        
        # Parse request details
        request_method, request_path, _ = self._parse_request(request_str)
        
        # Determine log level based on status code
        level = self._determine_level_from_status(status_code)
        
        return LogEntry(
            timestamp=timestamp,
            level=level,
            message=f"{request_method} {request_path} - {status_code}",
            ip_address=ip_address,
            status_code=status_code,
            request_method=request_method,
            request_path=request_path,
            user_agent=user_agent,
            bytes_sent=bytes_sent,
            referer=referer,
            raw_line=line
        )
    
    def _parse_common_format(self, match, line: str) -> LogEntry:
        """Parse Common Log Format line."""
        ip_address = match.group(1)
        timestamp_str = match.group(2)
        request_str = match.group(3)
        status_code = int(match.group(4))
        bytes_sent = int(match.group(5))
        
        # Parse timestamp
        timestamp = self._parse_apache_timestamp(timestamp_str)
        
        # Parse request details
        request_method, request_path, _ = self._parse_request(request_str)
        
        # Determine log level based on status code
        level = self._determine_level_from_status(status_code)
        
        return LogEntry(
            timestamp=timestamp,
            level=level,
            message=f"{request_method} {request_path} - {status_code}",
            ip_address=ip_address,
            status_code=status_code,
            request_method=request_method,
            request_path=request_path,
            bytes_sent=bytes_sent,
            raw_line=line
        )
    
    def _parse_apache_timestamp(self, timestamp_str: str) -> datetime:
        """Parse Apache timestamp format."""
        # Apache format: 25/Dec/2023:10:30:45 +0000
        try:
            return datetime.strptime(timestamp_str, '%d/%b/%Y:%H:%M:%S %z')
        except ValueError:
            # Try without timezone
            return datetime.strptime(timestamp_str, '%d/%b/%Y:%H:%M:%S')
    
    def _parse_request(self, request_str: str) -> tuple:
        """Parse HTTP request string into method, path, and protocol."""
        match = self.REQUEST_PATTERN.match(request_str)
        if match:
            return match.group(1), match.group(2), match.group(3)
        return "UNKNOWN", request_str, "HTTP/1.0"
    
    def _determine_level_from_status(self, status_code: int) -> str:
        """Determine log level based on HTTP status code."""
        if status_code >= 500:
            return "ERROR"
        elif status_code >= 400:
            return "WARN"
        else:
            return "INFO"
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "Apache"


class NginxLogParser(BaseLogParser):
    """
    Parser for Nginx web server log files.
    
    This parser handles the standard Nginx log format, which is similar to
    Apache's Combined Log Format but with some differences in field ordering
    and format. It extracts the same types of information as the Apache parser.
    """
    
    # Nginx log format pattern
    NGINX_PATTERN = re.compile(
        r'^(\S+) - (\S+) \[([^\]]+)\] "([^"]*)" (\d+) (\d+) "([^"]*)" "([^"]*)" "([^"]*)"$'
    )
    
    # Pattern to extract request method and path
    REQUEST_PATTERN = re.compile(r'^(\S+) (\S+) (\S+)$')
    
    def parse_line(self, line: str) -> Optional[LogEntry]:
        """
        Parse an Nginx log line into a LogEntry object.
        
        Args:
            line: Raw Nginx log line
            
        Returns:
            LogEntry object if parsing successful, None if line should be skipped
        """
        match = self.NGINX_PATTERN.match(line)
        if not match:
            return None
        
        ip_address = match.group(1)
        remote_user = match.group(2)
        timestamp_str = match.group(3)
        request_str = match.group(4)
        status_code = int(match.group(5))
        bytes_sent = int(match.group(6))
        referer = match.group(7)
        user_agent = match.group(8)
        forwarded_for = match.group(9)
        
        # Parse timestamp
        timestamp = self._parse_nginx_timestamp(timestamp_str)
        
        # Parse request details
        request_method, request_path, _ = self._parse_request(request_str)
        
        # Determine log level based on status code
        level = self._determine_level_from_status(status_code)
        
        return LogEntry(
            timestamp=timestamp,
            level=level,
            message=f"{request_method} {request_path} - {status_code}",
            ip_address=ip_address,
            status_code=status_code,
            request_method=request_method,
            request_path=request_path,
            user_agent=user_agent,
            bytes_sent=bytes_sent,
            referer=referer,
            raw_line=line
        )
    
    def _parse_nginx_timestamp(self, timestamp_str: str) -> datetime:
        """Parse Nginx timestamp format."""
        # Nginx format: 25/Dec/2023:10:30:45 +0000
        try:
            return datetime.strptime(timestamp_str, '%d/%b/%Y:%H:%M:%S %z')
        except ValueError:
            # Try without timezone
            return datetime.strptime(timestamp_str, '%d/%b/%Y:%H:%M:%S')
    
    def _parse_request(self, request_str: str) -> tuple:
        """Parse HTTP request string into method, path, and protocol."""
        match = self.REQUEST_PATTERN.match(request_str)
        if match:
            return match.group(1), match.group(2), match.group(3)
        return "UNKNOWN", request_str, "HTTP/1.0"
    
    def _determine_level_from_status(self, status_code: int) -> str:
        """Determine log level based on HTTP status code."""
        if status_code >= 500:
            return "ERROR"
        elif status_code >= 400:
            return "WARN"
        else:
            return "INFO"
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "Nginx"


class GenericLogParser(BaseLogParser):
    """
    Generic parser for custom log formats.
    
    This parser attempts to handle log formats that don't match the standard
    Apache or Nginx patterns. It uses heuristics to extract basic information
    and can be extended for specific custom formats.
    """
    
    # Generic patterns for common log elements
    TIMESTAMP_PATTERNS = [
        r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})',  # YYYY-MM-DD HH:MM:SS
        r'(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2})',  # MM/DD/YYYY HH:MM:SS
        r'(\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2})',  # MM-DD-YYYY HH:MM:SS
    ]
    
    LEVEL_PATTERN = re.compile(r'\b(ERROR|WARN|INFO|DEBUG|FATAL|CRITICAL)\b', re.IGNORECASE)
    IP_PATTERN = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
    
    def parse_line(self, line: str) -> Optional[LogEntry]:
        """
        Parse a generic log line using heuristics.
        
        Args:
            line: Raw log line
            
        Returns:
            LogEntry object if parsing successful, None if line should be skipped
        """
        # Extract timestamp
        timestamp = self._extract_timestamp(line)
        if not timestamp:
            return None
        
        # Extract log level
        level = self._extract_level(line)
        
        # Extract IP address
        ip_address = self._extract_ip(line)
        
        # Use the entire line as message if no specific parsing is possible
        message = line.strip()
        
        return LogEntry(
            timestamp=timestamp,
            level=level,
            message=message,
            ip_address=ip_address,
            raw_line=line
        )
    
    def _extract_timestamp(self, line: str) -> Optional[datetime]:
        """Extract timestamp from log line using multiple patterns."""
        for pattern in self.TIMESTAMP_PATTERNS:
            match = re.search(pattern, line)
            if match:
                timestamp_str = match.group(1)
                try:
                    # Try different timestamp formats
                    for fmt in ['%Y-%m-%d %H:%M:%S', '%m/%d/%Y %H:%M:%S', '%m-%d-%Y %H:%M:%S']:
                        try:
                            return datetime.strptime(timestamp_str, fmt)
                        except ValueError:
                            continue
                except Exception:
                    continue
        return None
    
    def _extract_level(self, line: str) -> str:
        """Extract log level from line."""
        match = self.LEVEL_PATTERN.search(line)
        if match:
            return match.group(1).upper()
        return "INFO"  # Default level
    
    def _extract_ip(self, line: str) -> Optional[str]:
        """Extract IP address from line."""
        match = self.IP_PATTERN.search(line)
        if match:
            return match.group(1)
        return None
    
    def get_format_name(self) -> str:
        """Return the format name."""
        return "Generic"


class LogParserFactory:
    """
    Factory class for creating appropriate log parsers.
    
    This class implements the Factory pattern to automatically select
    the most appropriate parser based on the log file content. It examines
    the first few lines of the file to determine the format and returns
    the corresponding parser instance.
    """
    
    @staticmethod
    def create_parser(file_path: str) -> BaseLogParser:
        """
        Create the appropriate parser for the given log file.
        
        Args:
            file_path: Path to the log file
            
        Returns:
            BaseLogParser instance appropriate for the file format
        """
        # Read first few lines to determine format
        format_type = LogParserFactory._detect_format(file_path)
        
        # Create appropriate parser
        if format_type == "apache":
            return ApacheLogParser(file_path)
        elif format_type == "nginx":
            return NginxLogParser(file_path)
        else:
            return GenericLogParser(file_path)
    
    @staticmethod
    def _detect_format(file_path: str) -> str:
        """
        Detect the log format by examining the file content.
        
        Args:
            file_path: Path to the log file
            
        Returns:
            String indicating the detected format
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                # Read first 10 lines to determine format
                for i, line in enumerate(file):
                    if i >= 10:  # Only check first 10 lines
                        break
                    
                    line = line.strip()
                    if not line:
                        continue
                    
                    # Check for Apache format
                    if ApacheLogParser.COMBINED_PATTERN.match(line) or \
                       ApacheLogParser.CLF_PATTERN.match(line):
                        return "apache"
                    
                    # Check for Nginx format
                    if NginxLogParser.NGINX_PATTERN.match(line):
                        return "nginx"
                
                # Default to generic if no specific format detected
                return "generic"
                
        except Exception:
            # If we can't read the file, default to generic
            return "generic" 