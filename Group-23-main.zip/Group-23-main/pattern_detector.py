
"""
Pattern Detector Module - Analysis and pattern detection logic

This module provides comprehensive analysis capabilities for log entries.
It detects various patterns including errors, anomalies, performance issues,
and user behavior patterns using regular expressions and statistical analysis.

The module includes:
- Error pattern detection (4xx, 5xx status codes)
- Performance analysis (response times, throughput)
- Anomaly detection (unusual traffic patterns)
- Security threat detection (failed logins, suspicious IPs)
- User behavior analysis (peak usage, patterns)

"""

import re
import statistics
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from collections import defaultdict, Counter
from dataclasses import dataclass

from log_parser import LogEntry


@dataclass
class AnalysisResult:
    """
    Data class containing the results of log analysis.
    
    This class encapsulates all the metrics, patterns, and insights
    discovered during the analysis process.
    """
    # Basic statistics
    total_entries: int
    total_requests: int
    average_response_time: Optional[float]
    
    # Error analysis
    error_count: int
    error_rate: float
    status_code_distribution: Dict[int, int]
    repeated_errors: List[Dict[str, Any]]
    
    # Performance metrics
    response_time_stats: Dict[str, float]
    peak_usage_periods: List[Dict[str, Any]]
    slow_requests: List[Dict[str, Any]]
    
    # Security analysis
    suspicious_ips: List[Dict[str, Any]]
    failed_logins: List[Dict[str, Any]]
    
    # Traffic analysis
    hourly_traffic: Dict[int, int]
    daily_traffic: Dict[str, int]
    top_endpoints: List[Tuple[str, int]]
    top_user_agents: List[Tuple[str, int]]
    
    # Anomalies and alerts
    anomalies: List[Dict[str, Any]]
    alerts: List[Dict[str, Any]]
    
    # Recommendations
    recommendations: List[str]


class PatternDetector:
    """
    Main class for detecting patterns and analyzing log data.
    
    This class provides comprehensive analysis capabilities including
    error detection, performance monitoring, security analysis, and
    anomaly detection. It uses both regex patterns and statistical
    analysis to identify issues and trends.
    """
    
    def __init__(self, threshold: int = 10):
        """
        Initialize the pattern detector.
        
        Args:
            threshold: Threshold for generating alerts (default: 10)
        """
        self.threshold = threshold
        
        # Regular expressions for pattern detection
        self.error_patterns = {
            'authentication_failure': re.compile(r'(?i)(failed|invalid|incorrect|wrong).*(password|login|auth|credential)', re.IGNORECASE),
            'file_not_found': re.compile(r'(?i)(404|not found|file not found|page not found)', re.IGNORECASE),
            'server_error': re.compile(r'(?i)(500|internal server error|server error)', re.IGNORECASE),
        }
        
        # Performance thresholds
        self.slow_response_threshold = 1000  # milliseconds
        self.high_error_rate_threshold = 0.05  # 5%
        self.unusual_traffic_threshold = 2.0  # 2x average
    
    def analyze(self, log_entries: List[LogEntry]) -> AnalysisResult:
        """
        Perform comprehensive analysis of log entries.
        
        Args:
            log_entries: List of parsed log entries to analyze
            
        Returns:
            AnalysisResult object containing all analysis findings
        """
        if not log_entries:
            return self._create_empty_result()
        
        print(f"Analyzing {len(log_entries)} log entries...")
        
        # Basic statistics
        total_entries = len(log_entries)
        total_requests = self._count_requests(log_entries)
        
        # Error analysis
        error_analysis = self._analyze_errors(log_entries)
        
        # Performance analysis
        performance_analysis = self._analyze_performance(log_entries)
        
        # Security analysis
        security_analysis = self._analyze_security(log_entries)
        
        # Traffic analysis
        traffic_analysis = self._analyze_traffic(log_entries)
        
        # Anomaly detection
        anomalies = self._detect_anomalies(log_entries, traffic_analysis)
        
        # Generate alerts
        alerts = self._generate_alerts(error_analysis, performance_analysis, anomalies)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(
            error_analysis, performance_analysis, security_analysis, anomalies
        )
        
        return AnalysisResult(
            total_entries=total_entries,
            total_requests=total_requests,
            average_response_time=performance_analysis.get('average_response_time'),
            error_count=error_analysis['error_count'],
            error_rate=error_analysis['error_rate'],
            status_code_distribution=error_analysis['status_code_distribution'],
            repeated_errors=error_analysis['repeated_errors'],
            response_time_stats=performance_analysis.get('response_time_stats', {}),
            peak_usage_periods=traffic_analysis['peak_usage_periods'],
            slow_requests=performance_analysis.get('slow_requests', []),
            suspicious_ips=security_analysis['suspicious_ips'],
            failed_logins=security_analysis['failed_logins'],
            hourly_traffic=traffic_analysis['hourly_traffic'],
            daily_traffic=traffic_analysis['daily_traffic'],
            top_endpoints=traffic_analysis['top_endpoints'],
            top_user_agents=traffic_analysis['top_user_agents'],
            anomalies=anomalies,
            alerts=alerts,
            recommendations=recommendations
        )
    
    def _create_empty_result(self) -> AnalysisResult:
        """Create an empty analysis result for empty log files."""
        return AnalysisResult(
            total_entries=0,
            total_requests=0,
            average_response_time=None,
            error_count=0,
            error_rate=0.0,
            status_code_distribution={},
            repeated_errors=[],
            response_time_stats={},
            peak_usage_periods=[],
            slow_requests=[],
            suspicious_ips=[],
            failed_logins=[],
            hourly_traffic={},
            daily_traffic={},
            top_endpoints=[],
            top_user_agents=[],
            anomalies=[],
            alerts=[],
            recommendations=["No log entries to analyze"]
        )
    
    def _count_requests(self, log_entries: List[LogEntry]) -> int:
        """Count total HTTP requests in log entries."""
        return sum(1 for entry in log_entries if entry.status_code is not None)
    
    def _analyze_errors(self, log_entries: List[LogEntry]) -> Dict[str, Any]:
        """
        Analyze error patterns in log entries.
        
        Args:
            log_entries: List of log entries to analyze
            
        Returns:
            Dictionary containing error analysis results
        """
        error_entries = [entry for entry in log_entries if entry.level in ['ERROR', 'WARN']]
        error_count = len(error_entries)
        total_entries = len(log_entries)
        error_rate = error_count / total_entries if total_entries > 0 else 0.0
        
        # Status code distribution
        status_code_distribution = Counter()
        for entry in log_entries:
            if entry.status_code:
                status_code_distribution[entry.status_code] += 1
        
        # Find repeated errors
        repeated_errors = self._find_repeated_errors(log_entries)
        
        return {
            'error_count': error_count,
            'error_rate': error_rate,
            'status_code_distribution': dict(status_code_distribution),
            'repeated_errors': repeated_errors
        }
    
    def _find_repeated_errors(self, log_entries: List[LogEntry]) -> List[Dict[str, Any]]:
        """Find patterns of repeated errors."""
        error_patterns = defaultdict(list)
        
        for entry in log_entries:
            if entry.level in ['ERROR', 'WARN'] and entry.status_code:
                # Group by status code and endpoint
                key = f"{entry.status_code}:{entry.request_path or 'unknown'}"
                error_patterns[key].append(entry)
        
        repeated_errors = []
        for pattern, entries in error_patterns.items():
            if len(entries) >= self.threshold:
                status_code, endpoint = pattern.split(':', 1)
                repeated_errors.append({
                    'pattern': pattern,
                    'status_code': int(status_code),
                    'endpoint': endpoint,
                    'count': len(entries),
                    'first_occurrence': min(entry.timestamp for entry in entries),
                    'last_occurrence': max(entry.timestamp for entry in entries),
                    'time_span': max(entry.timestamp for entry in entries) - min(entry.timestamp for entry in entries)
                })
        
        return sorted(repeated_errors, key=lambda x: x['count'], reverse=True)
    
    def _analyze_performance(self, log_entries: List[LogEntry]) -> Dict[str, Any]:
        """
        Analyze performance metrics from log entries.
        
        Args:
            log_entries: List of log entries to analyze
            
        Returns:
            Dictionary containing performance analysis results
        """
        # Extract response times (if available)
        response_times = []
        slow_requests = []
        
        for entry in log_entries:
            if entry.response_time is not None:
                response_times.append(entry.response_time)
                
                # Check for slow requests
                if entry.response_time > self.slow_response_threshold:
                    slow_requests.append({
                        'timestamp': entry.timestamp,
                        'endpoint': entry.request_path or 'unknown',
                        'response_time': entry.response_time,
                        'status_code': entry.status_code,
                        'ip_address': entry.ip_address
                    })
        
        # Calculate response time statistics
        response_time_stats = {}
        if response_times:
            response_time_stats = {
                'min': min(response_times),
                'max': max(response_times),
                'mean': statistics.mean(response_times),
                'median': statistics.median(response_times),
                'std_dev': statistics.stdev(response_times) if len(response_times) > 1 else 0
            }
        
        return {
            'response_time_stats': response_time_stats,
            'average_response_time': statistics.mean(response_times) if response_times else None,
            'slow_requests': sorted(slow_requests, key=lambda x: x['response_time'], reverse=True)
        }
    
    def _analyze_security(self, log_entries: List[LogEntry]) -> Dict[str, Any]:
        """
        Analyze security-related patterns in log entries.
        
        Args:
            log_entries: List of log entries to analyze
            
        Returns:
            Dictionary containing security analysis results
        """
        suspicious_ips = []
        failed_logins = []
        
        # Analyze IP addresses for suspicious activity
        ip_activity = defaultdict(list)
        for entry in log_entries:
            if entry.ip_address:
                ip_activity[entry.ip_address].append(entry)
        
        # Find suspicious IPs (high error rate, unusual patterns)
        for ip, entries in ip_activity.items():
            error_count = sum(1 for entry in entries if entry.level in ['ERROR', 'WARN'])
            error_rate = error_count / len(entries) if entries else 0
            
            if error_rate > 0.5:  # More than 50% errors
                suspicious_ips.append({
                    'ip_address': ip,
                    'total_requests': len(entries),
                    'error_count': error_count,
                    'error_rate': error_rate,
                    'first_seen': min(entry.timestamp for entry in entries),
                    'last_seen': max(entry.timestamp for entry in entries)
                })
        
        # Find failed login attempts
        for entry in log_entries:
            if entry.message and self.error_patterns['authentication_failure'].search(entry.message):
                failed_logins.append({
                    'timestamp': entry.timestamp,
                    'ip_address': entry.ip_address,
                    'message': entry.message,
                    'endpoint': entry.request_path
                })
        
        return {
            'suspicious_ips': sorted(suspicious_ips, key=lambda x: x['error_rate'], reverse=True),
            'failed_logins': failed_logins
        }
    
    def _analyze_traffic(self, log_entries: List[LogEntry]) -> Dict[str, Any]:
        """
        Analyze traffic patterns and usage statistics.
        
        Args:
            log_entries: List of log entries to analyze
            
        Returns:
            Dictionary containing traffic analysis results
        """
        # Hourly traffic distribution
        hourly_traffic = defaultdict(int)
        for entry in log_entries:
            hour = entry.timestamp.hour
            hourly_traffic[hour] += 1
        
        # Daily traffic distribution
        daily_traffic = defaultdict(int)
        for entry in log_entries:
            day = entry.timestamp.strftime('%Y-%m-%d')
            daily_traffic[day] += 1
        
        # Top endpoints
        endpoint_counts = Counter()
        for entry in log_entries:
            if entry.request_path:
                endpoint_counts[entry.request_path] += 1
        
        # Top user agents
        user_agent_counts = Counter()
        for entry in log_entries:
            if entry.user_agent:
                user_agent_counts[entry.user_agent] += 1
        
        # Find peak usage periods
        peak_usage_periods = self._find_peak_usage_periods(log_entries)
        
        return {
            'hourly_traffic': dict(hourly_traffic),
            'daily_traffic': dict(daily_traffic),
            'top_endpoints': endpoint_counts.most_common(10),
            'top_user_agents': user_agent_counts.most_common(5),
            'peak_usage_periods': peak_usage_periods
        }
    
    def _find_peak_usage_periods(self, log_entries: List[LogEntry]) -> List[Dict[str, Any]]:
        """Find periods of peak usage."""
        # Group entries by hour
        hourly_groups = defaultdict(list)
        for entry in log_entries:
            hour_key = entry.timestamp.replace(minute=0, second=0, microsecond=0)
            hourly_groups[hour_key].append(entry)
        
        # Calculate average requests per hour
        requests_per_hour = [len(entries) for entries in hourly_groups.values()]
        if not requests_per_hour:
            return []
        
        avg_requests = statistics.mean(requests_per_hour)
        threshold = avg_requests * self.unusual_traffic_threshold
        
        # Find peak periods
        peak_periods = []
        for hour, entries in hourly_groups.items():
            if len(entries) > threshold:
                peak_periods.append({
                    'hour': hour,
                    'request_count': len(entries),
                    'average_requests': avg_requests,
                    'peak_factor': len(entries) / avg_requests
                })
        
        return sorted(peak_periods, key=lambda x: x['request_count'], reverse=True)
    
    def _detect_anomalies(self, log_entries: List[LogEntry], traffic_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Detect anomalies in log data.
        
        Args:
            log_entries: List of log entries to analyze
            traffic_analysis: Results from traffic analysis
            
        Returns:
            List of detected anomalies
        """
        anomalies = []
        
        # Detect unusual traffic patterns
        hourly_traffic = traffic_analysis['hourly_traffic']
        if hourly_traffic:
            avg_traffic = statistics.mean(hourly_traffic.values())
            std_dev = statistics.stdev(hourly_traffic.values()) if len(hourly_traffic) > 1 else 0
            
            for hour, count in hourly_traffic.items():
                if std_dev > 0 and abs(count - avg_traffic) > 2 * std_dev:
                    anomalies.append({
                        'type': 'unusual_traffic',
                        'hour': hour,
                        'traffic_count': count,
                        'expected_range': f"{avg_traffic - 2*std_dev:.1f} - {avg_traffic + 2*std_dev:.1f}",
                        'severity': 'high' if abs(count - avg_traffic) > 3 * std_dev else 'medium'
                    })
        
        # Detect unusual error patterns
        error_entries = [entry for entry in log_entries if entry.level in ['ERROR', 'WARN']]
        if error_entries:
            # Group errors by hour
            error_hourly = defaultdict(int)
            for entry in error_entries:
                hour = entry.timestamp.hour
                error_hourly[hour] += 1
            
            # Find hours with unusually high error rates
            total_requests = len(log_entries)
            for hour, error_count in error_hourly.items():
                error_rate = error_count / total_requests
                if error_rate > self.high_error_rate_threshold:
                    anomalies.append({
                        'type': 'high_error_rate',
                        'hour': hour,
                        'error_count': error_count,
                        'error_rate': error_rate,
                        'threshold': self.high_error_rate_threshold,
                        'severity': 'high' if error_rate > 0.1 else 'medium'
                    })
        
        return anomalies
    
    def _generate_alerts(self, error_analysis: Dict[str, Any], 
                        performance_analysis: Dict[str, Any],
                        anomalies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Generate alerts based on analysis results.
        
        Args:
            error_analysis: Results from error analysis
            performance_analysis: Results from performance analysis
            anomalies: List of detected anomalies
            
        Returns:
            List of generated alerts
        """
        alerts = []
        
        # Error rate alerts
        if error_analysis['error_rate'] > self.high_error_rate_threshold:
            alerts.append({
                'type': 'high_error_rate',
                'message': f"High error rate detected: {error_analysis['error_rate']:.2%}",
                'severity': 'high',
                'value': error_analysis['error_rate']
            })
        
        # Repeated errors alerts
        for error in error_analysis['repeated_errors']:
            alerts.append({
                'type': 'repeated_errors',
                'message': f"Repeated {error['status_code']} errors on {error['endpoint']}: {error['count']} occurrences",
                'severity': 'medium',
                'details': error
            })
        
        # Performance alerts
        if performance_analysis.get('slow_requests'):
            slow_count = len(performance_analysis['slow_requests'])
            alerts.append({
                'type': 'slow_requests',
                'message': f"{slow_count} slow requests detected (> {self.slow_response_threshold}ms)",
                'severity': 'medium',
                'count': slow_count
            })
        
        # Anomaly alerts
        for anomaly in anomalies:
            alerts.append({
                'type': f"anomaly_{anomaly['type']}",
                'message': f"Anomaly detected: {anomaly['type']}",
                'severity': anomaly['severity'],
                'details': anomaly
            })
        
        return alerts
    
    def _generate_recommendations(self, error_analysis: Dict[str, Any],
                                performance_analysis: Dict[str, Any],
                                security_analysis: Dict[str, Any],
                                anomalies: List[Dict[str, Any]]) -> List[str]:
        """
        Generate recommendations based on analysis results.
        
        Args:
            error_analysis: Results from error analysis
            performance_analysis: Results from performance analysis
            security_analysis: Results from security analysis
            anomalies: List of detected anomalies
            
        Returns:
            List of recommendations
        """
        recommendations = []
        
        # Error-based recommendations
        if error_analysis['error_rate'] > 0.05:
            recommendations.append("Investigate high error rate - consider server health and configuration")
        
        for error in error_analysis['repeated_errors']:
            recommendations.append(f"Fix repeated {error['status_code']} errors on {error['endpoint']}")
        
        # Performance-based recommendations
        if performance_analysis.get('slow_requests'):
            recommendations.append("Optimize slow endpoints to improve response times")
        
        # Security-based recommendations
        if security_analysis['suspicious_ips']:
            recommendations.append("Review and potentially block suspicious IP addresses")
        
        if security_analysis['failed_logins']:
            recommendations.append("Implement rate limiting for authentication endpoints")
        
        # Traffic-based recommendations
        if anomalies:
            recommendations.append("Monitor traffic patterns for unusual activity")
        
        if not recommendations:
            recommendations.append("Log analysis shows normal operation - continue monitoring")
        
        return recommendations 