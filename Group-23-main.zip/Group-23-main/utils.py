
"""
Utilities Module - Helper functions and validation utilities

This module provides utility functions for the log analyzer application,
including input validation, file handling utilities, and common helper
functions used across multiple modules.

The module includes:
- File path validation
- Date format validation
- Log level validation
- Common utility functions
- Error handling helpers

"""

import os
import re
from datetime import datetime
from typing import Optional, Tuple


def validate_file_path(file_path: str) -> bool:
    """
    Validate that a file path exists and is readable.
    
    This function checks if the specified file exists and can be read.
    It provides a safe way to validate file paths before attempting
    to process them.
    
    Args:
        file_path: Path to the file to validate
        
    Returns:
        True if the file exists and is readable, False otherwise
    """
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            return False
        
        # Check if it's a file (not a directory)
        if not os.path.isfile(file_path):
            return False
        
        # Check if file is readable
        if not os.access(file_path, os.R_OK):
            return False
        
        return True
        
    except (OSError, ValueError):
        return False


def validate_date_format(date_string: str) -> bool:
    """
    Validate that a date string is in the correct format (YYYY-MM-DD).
    
    This function checks if the provided date string matches the expected
    format and represents a valid date. It's used for validating command-line
    arguments and user input.
    
    Args:
        date_string: Date string to validate
        
    Returns:
        True if the date string is valid, False otherwise
    """
    try:
        # Check if the string matches the expected format
        if not re.match(r'^\d{4}-\d{2}-\d{2}$', date_string):
            return False
        
        # Try to parse the date to ensure it's valid
        datetime.strptime(date_string, '%Y-%m-%d')
        return True
        
    except ValueError:
        return False


def validate_log_level(level: str) -> bool:
    """
    Validate that a log level is supported.
    
    This function checks if the provided log level is one of the
    supported levels used in the application.
    
    Args:
        level: Log level string to validate
        
    Returns:
        True if the log level is valid, False otherwise
    """
    valid_levels = {'ERROR', 'WARN', 'INFO', 'DEBUG'}
    return level.upper() in valid_levels





def parse_timestamp_range(start_date: Optional[str], 
                         end_date: Optional[str]) -> Tuple[Optional[datetime], Optional[datetime]]:
    """
    Parse start and end date strings into datetime objects.
    
    This function safely converts date strings to datetime objects
    for use in filtering log entries. It handles validation and
    provides clear error messages for invalid dates.
    
    Args:
        start_date: Start date string (YYYY-MM-DD format)
        end_date: End date string (YYYY-MM-DD format)
        
    Returns:
        Tuple of (start_datetime, end_datetime) or (None, None) if invalid
        
    Raises:
        ValueError: If date strings are invalid
    """
    start_dt = None
    end_dt = None
    
    if start_date:
        if not validate_date_format(start_date):
            raise ValueError(f"Invalid start date format: {start_date}. Use YYYY-MM-DD format.")
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
    
    if end_date:
        if not validate_date_format(end_date):
            raise ValueError(f"Invalid end date format: {end_date}. Use YYYY-MM-DD format.")
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
    
    # Validate date range
    if start_dt and end_dt and start_dt > end_dt:
        raise ValueError("Start date cannot be after end date.")
    
    return start_dt, end_dt





def safe_int_conversion(value: str, default: int = 0) -> int:
    """
    Safely convert a string to an integer with a default value.
    
    This function attempts to convert a string to an integer and returns
    a default value if the conversion fails. It's useful for parsing
    numeric values from log entries or user input.
    
    Args:
        value: String value to convert
        default: Default value to return if conversion fails
        
    Returns:
        Integer value or default if conversion fails
    """
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def safe_float_conversion(value: str, default: float = 0.0) -> float:
    """
    Safely convert a string to a float with a default value.
    
    This function attempts to convert a string to a float and returns
    a default value if the conversion fails. It's useful for parsing
    decimal values from log entries.
    
    Args:
        value: String value to convert
        default: Default value to return if conversion fails
        
    Returns:
        Float value or default if conversion fails
    """
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def extract_ip_address(text: str) -> Optional[str]:
    """
    Extract IP address from text using regex.
    
    This function uses a regular expression to find and extract
    IPv4 addresses from text. It's useful for parsing log entries
    that contain IP addresses in various formats.
    
    Args:
        text: Text to search for IP addresses
        
    Returns:
        First IP address found or None if no IP address is found
    """
    # IPv4 pattern
    ip_pattern = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
    match = ip_pattern.search(text)
    
    if match:
        ip = match.group()
        # Validate that each octet is in valid range
        octets = ip.split('.')
        if all(0 <= int(octet) <= 255 for octet in octets):
            return ip
    
    return None





 